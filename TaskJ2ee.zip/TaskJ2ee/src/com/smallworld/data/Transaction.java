package com.smallworld.data;

public class Transaction {
    private int id;
    private String senderFullName;
    private String beneficiaryName;
    private double amount;
    private boolean complianceIssueSolved;

    public Transaction(int id, String senderFullName, String beneficiaryName, double amount, boolean complianceIssueSolved) {
        this.id = id;
        this.senderFullName = senderFullName;
        this.beneficiaryName = beneficiaryName;
        this.amount = amount;
        this.complianceIssueSolved = complianceIssueSolved;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSenderFullName() {
        return senderFullName;
    }

    public void setSenderFullName(String senderFullName) {
        this.senderFullName = senderFullName;
    }

    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public boolean isComplianceIssueSolved() {
        return complianceIssueSolved;
    }

    public void setComplianceIssueSolved(boolean complianceIssueSolved) {
        this.complianceIssueSolved = complianceIssueSolved;
    }
}
