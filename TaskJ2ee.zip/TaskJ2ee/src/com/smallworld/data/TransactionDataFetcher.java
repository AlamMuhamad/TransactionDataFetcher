package com.smallworld.data;

import com.smallworld.data.Transaction;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class TransactionDataFetcher {

    private List<Transaction> transactions; // Assuming you have a list of transactions

    public TransactionDataFetcher(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public double getTotalTransactionAmount() {
        return transactions.stream().mapToDouble(Transaction::getAmount).sum();
    }

    public double getTotalTransactionAmountSentBy(String senderFullName) {
        return transactions.stream()
                .filter(transaction -> transaction.getSenderFullName().equals(senderFullName))
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public double getMaxTransactionAmount() {
        return transactions.stream().mapToDouble(Transaction::getAmount).max().orElse(0);
    }

    public long countUniqueClients() {
        return transactions.stream()
                .flatMap(transaction -> List.of(transaction.getSenderFullName(), transaction.getBeneficiaryName()).stream())
                .distinct()
                .count();
    }

    public boolean hasOpenComplianceIssues(String clientFullName) {
        return transactions.stream()
                .anyMatch(transaction -> transaction.getSenderFullName().equals(clientFullName)
                        || transaction.getBeneficiaryName().equals(clientFullName));
    }

    public Map<String, Transaction> getTransactionsByBeneficiaryName() {
        return transactions.stream().collect(Collectors.toMap(Transaction::getBeneficiaryName, Function.identity()));
    }

    public Set<Integer> getUnsolvedIssueIds() {
        return transactions.stream()
                .filter(transaction -> !transaction.isComplianceIssueSolved())
                .map(Transaction::getId)
                .collect(Collectors.toSet());
    }

    public List<String> getAllSolvedIssueMessages() {
        return transactions.stream()
                .filter(Transaction::isComplianceIssueSolved)
                .map(transaction -> "Issue resolved for transaction with ID: " + transaction.getId())
                .collect(Collectors.toList());
    }

    public List<Transaction> getTop3TransactionsByAmount() {
        return transactions.stream()
                .sorted(Comparator.comparingDouble(Transaction::getAmount).reversed())
                .limit(3)
                .collect(Collectors.toList());
    }

    public Optional<String> getTopSender() {
        return transactions.stream()
                .collect(Collectors.groupingBy(Transaction::getSenderFullName, Collectors.summingDouble(Transaction::getAmount)))
                .entrySet()
                .stream()
                .max(Comparator.comparingDouble(Map.Entry::getValue))
                .map(Map.Entry::getKey);
    }
}
